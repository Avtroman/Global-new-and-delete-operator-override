How to build:

This project for Visual Studio '2022
Make "Include" directory is add to default include directory

Only for x64
