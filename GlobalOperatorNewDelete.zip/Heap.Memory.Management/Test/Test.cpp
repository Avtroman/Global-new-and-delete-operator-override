﻿// Test.cpp : Определяет точку входа для приложения.
//

#include "framework.h"
#include "Test.h"
#include <StdAfx.h>



#define XXX



VOID MemoryZero (VOID*, ULONG_MAXIMUM);



VOID* AllocateMemoryBlock (ULONG_MAXIMUM);



int APIENTRY wWinMain (_In_ HINSTANCE hInstance,
					   _In_opt_ HINSTANCE hPrevInstance,
					   _In_ LPWSTR    lpCmdLine,
					   _In_ int       nCmdShow)
{



	// Allocate 30 bytes. Will be allocated 48 bytes
	BYTE* pbAllocate = new BYTE[30];




	delete[] pbAllocate;


	return (TRUE);

}