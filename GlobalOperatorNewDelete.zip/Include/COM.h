#pragma once

#if !defined _COM_H_DC8D0512_1DC4_44EB_A1E1_AAE66204B167
#define _COM_H_DC8D0512_1DC4_44EB_A1E1_AAE66204B167


#include "StdAfx.h"

#include <ObjBase.h>















#endif






