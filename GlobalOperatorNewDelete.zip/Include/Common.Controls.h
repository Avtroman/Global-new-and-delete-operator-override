#pragma once

#ifndef COMMON_CONTROLS_H_F7C2EFCC_A1E6_40B1_8B13_29282A8EE106

#define COMMON_CONTROLS_H_F7C2EFCC_A1E6_40B1_8B13_29282A8EE106




#include <Commctrl.h>






#if defined (_UNICODE)
	#if defined _M_IX86
		#pragma comment(linker,"/manifestdependency:\"type='win32' name='Microsoft.Windows.Common-Controls' version='6.0.0.0' processorArchitecture='x86' publicKeyToken='6595b64144ccf1df' language='*'\"")
	#elif defined _M_X64
		#pragma comment(linker,"/manifestdependency:\"type='win32' name='Microsoft.Windows.Common-Controls' version='6.0.0.0' processorArchitecture='amd64' publicKeyToken='6595b64144ccf1df' language='*'\"")
	#else
		#pragma comment(linker,"/manifestdependency:\"type='win32' name='Microsoft.Windows.Common-Controls' version='6.0.0.0' processorArchitecture='*' publicKeyToken='6595b64144ccf1df' language='*'\"")
	#endif
#endif




#pragma comment (lib, "comctl32.lib")
























#endif //  COMMON_CONTROLS_H_F7C2EFCC_A1E6_40B1_8B13_29282A8EE106








