#pragma once

#ifndef DBGPRINT_H_C623BA01_45B8_4542_A538_4FDB63428FDB
#define DBGPRINT_H_C623BA01_45B8_4542_A538_4FDB63428FDB





#include <Windows.Definitions.h>


//#include <NtDDK.h>

//#include <Wdm.h>




//#pragma comment (lib, "ntdll.lib")

//#pragma comment (lib, "NtosKrnl.lib")






#endif //  STDAFX_H_8F64AC40_65D2_4FAC_8E9F_ECA06EE41FF8







