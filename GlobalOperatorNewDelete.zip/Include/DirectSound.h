#pragma once

#if !defined _DIRECTSOUND_H_09727D40_7AEB_4505_8F3D_53FA76429D5D
#define _DIRECTSOUND_H_09727D40_7AEB_4505_8F3D_53FA76429D5D







#include <StdAfx.h>


#include <mmeapi.h>

#include <dsound.h>








#endif
