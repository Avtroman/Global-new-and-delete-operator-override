#pragma once

#if !defined GDI_PLUS_H_C74AC4C2_0E1B_4214_8B4C_33DF2598D0B5
#define GDI_PLUS_H_C74AC4C2_0E1B_4214_8B4C_33DF2598D0B5


#include <StdAfx.h>


#include <GdiPlus.h>


#pragma comment (lib, "gdiplus.lib")













#endif
