#pragma once









#define _GET(variable,function) __declspec (property (get=function)) variale

#define _SET(variable,function) __declspec (property (set=function)) variale



#define _PUTGET(variable,functionget,functionput) __declspec (property (get=functionget, put=functionput)) variale

#define _GETPUT(variable,functionget,functionput) __declspec (property (get=functionget, put=functionput)) variale



