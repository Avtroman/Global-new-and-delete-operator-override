#pragma once

#ifndef RELEASE_H_4C7A7530_8AFB_4F0F_A84B_39A0FDF7F060
#define RELEASE_H_4C7A7530_8AFB_4F0F_A84B_39A0FDF7F060



typedef int INT;

#if defined (_WIN32)

	#if defined (_M_AMD64)

		typedef			unsigned long long				ULONG64;

		typedef			long long						LONG64;

		typedef			unsigned long long				ULONG_MAXIMUM;

		typedef			long long						LONG_MAXIMUM;

		typedef			unsigned long long				BOOL_MAXIMUM;



	#endif

	#if defined (_M_IX86)

		typedef			unsigned long					ULONG32;

		typedef			long long						LONG32;

		typedef			unsigned long					ULONG_MAXIMUM;

		typedef			long							LONG_MAXIMUM;

		typedef			unsigned long					BOOL_MAXIMUM;

	#endif


#endif



#if defined (NDEBUG)

	// Release build
	#define _RELEASE

#endif


#if defined (_RELEASE)

	#pragma auto_inline (on)


	#pragma warning(disable:4711)

	// /Og (global optimizations), /Os (favor small code), /Oy (no frame pointers)
//	#pragma optimize("gsy",on)

//#if (_MSC_VER<1300)
	#pragma comment(linker,"/RELEASE")
//#endif

	// Note that merging the .rdata section will result in LARGER exe's if you using
	// MFC (esp. static link). If this is desirable, define _MERGE_RDATA_ in your project.
	//#ifdef _MERGE_RDATA_
	//#pragma comment(linker,"/merge:.rdata=.data")
	//#endif // _MERGE_RDATA_

	//#pragma comment(linker,"/merge:.text=.data")

	#if (_MSC_VER<1300)
		// In VC7, this causes problems with the relocation and data tables, so best to not merge them
		#pragma comment(linker,"/merge:.reloc=.data")
	#endif

	// Merging sections with different attributes causes a linker warning, so
	// turn off the warning. From Michael Geary. Undocumented, as usual!
	#if (_MSC_VER<1300)
		// In VC7, you will need to put this in your project settings
		#pragma comment(linker,"/ignore:4078")
	#endif

// With Visual C++ 5, you already get the 512-byte alignment, so you will only need
// it for VC6, and maybe later.
#if _MSC_VER >= 1000


	// ������������ �������� � �����.
	// �������������� 512, 1024, 2048, 4096 � 8192 ����.
	#pragma comment(linker,"/FILEALIGN:0x2000")

// Option #2: use /opt:nowin98
// See KB:Q235956 or the READMEVC.htm in your VC directory for info on this one.
// This is our currently preferred option, since it is fully documented and unlikely
// to break in service packs and updates.
#if (_MSC_VER<1300)
	// In VC7, you will need to put this in your project settings
	#pragma comment(linker,"/opt:nowin98")
#else

	// Option #3: use /align:4096
	// A side effect of using the default align value is that it turns on the above switch.
	// Does nothing under Vc7 that /opt:nowin98 doesn't already give you
	#pragma comment(linker,"/ALIGN:512")
#endif


#endif // NDEBUG

#endif //  RELEASE_H_4C7A7530_8AFB_4F0F_A84B_39A0FDF7F060







#endif // _RELEASE
