#pragma once

#ifndef STDAFX_H_8F64AC40_65D2_4FAC_8E9F_ECA06EE41FF8
#define STDAFX_H_8F64AC40_65D2_4FAC_8E9F_ECA06EE41FF8




#include <WinSdkVer.h>

// // ��� ��������� SDKDDKVer.h ����� ������ ����� ����� �� ��������� �������� Windows.
// ���� �� ���������� ������ ���������� ��� ���������� ������ ��������� Windows, �������� WinSDKVer.h �
// ������� �������� ��������� � ������� _WIN32_WINNT, ������ ��� �������� SDKDDKVer.h.
#include <SDKDDKVer.h>



#define WIN32_LEAN_AND_MEAN             // ��������� ����� ������������ ���������� �� ���������� Windows
// ����� ���������� Windows
#include <windows.h>
// ����� ���������� ����� ���������� C
#include <stdlib.h>
#include <malloc.h>
#include <memory.h>
#include <tchar.h>




#include <Windows.Definitions.h>

#include <Release.h>
#include <Macros.h>




#if defined (_XMM)
#include <xmmintrin.h>
#endif




#if defined (_COM)
#include <ObjBase.h>

#pragma comment (linker, "ole32.lib")


#endif

#define _ROUND(number,roundto) (number + (roundto-1)) & ~(roundto-1)




// Windows 8.1 NTDDI_WINBLUE (0x06030000)
// Windows 8 NTDDI_WIN8 (0x06020000)
// Windows 7 NTDDI_WIN7 (0x06010000)
// Windows Server 2008 NTDDI_WS08 (0x06000100)
// Windows Vista with Service Pack 1 (SP1)NTDDI_VISTASP1 (0x06000100)
// Windows Vista NTDDI_VISTA (0x06000000)
// Windows Server 2003 with Service Pack 2 (SP2)NTDDI_WS03SP2 (0x05020200)
// Windows Server 2003 with Service Pack 1 (SP1)NTDDI_WS03SP1 (0x05020100)
// Windows Server 2003 NTDDI_WS03 (0x05020000)
// Windows XP with Service Pack 3 (SP3)NTDDI_WINXPSP3 (0x05010300)
// Windows XP with Service Pack 2 (SP2)NTDDI_WINXPSP2 (0x05010200)
// Windows XP with Service Pack 1 (SP1)NTDDI_WINXPSP1 (0x05010100)
// Windows XP NTDDI_WINXP (0x05010000)
//
//
// The following tables describe other macros used in the Windows header files.
//
//
// Minimum system required
//
// Minimum value for _WIN32_WINNT and WINVER
//
//
// Windows 8.1 _WIN32_WINNT_WINBLUE (0x0602)
// Windows 8 _WIN32_WINNT_WIN8 (0x0602)
// Windows 7 _WIN32_WINNT_WIN7 (0x0601)
// Windows Server 2008 _WIN32_WINNT_WS08 (0x0600)
// Windows Vista _WIN32_WINNT_VISTA (0x0600)
// Windows Server 2003 with SP1, Windows XP with SP2 _WIN32_WINNT_WS03 (0x0502)
// Windows Server 2003, Windows XP _WIN32_WINNT_WINXP (0x0501)
//
//
//
// Minimum version required
//
// Minimum value of _WIN32_IE
//
//
// Internet Explorer 10.0 _WIN32_IE_IE100 (0x0A00)
// Internet Explorer 9.0 _WIN32_IE_IE90 (0x0900)
// Internet Explorer 8.0 _WIN32_IE_IE80 (0x0800)
// Internet Explorer 7.0 _WIN32_IE_IE70 (0x0700)
// Internet Explorer 6.0 SP2 _WIN32_IE_IE60SP2 (0x0603)
// Internet Explorer 6.0 SP1 _WIN32_IE_IE60SP1 (0x0601)
// Internet Explorer 6.0 _WIN32_IE_IE60 (0x0600)
// Internet Explorer 5.5 _WIN32_IE_IE55 (0x0550)
// Internet Explorer 5.01 _WIN32_IE_IE501 (0x0501)
// Internet Explorer 5.0, 5.0a, 5.0b _WIN32_IE_IE50 (0x0500)
//


#define _INTERNET_EXPLORER_10




#if defined (_INTERNET_EXPLORER_10)
#define _INTERNET_EXPLORER_10
#endif


#if defined (_INTERNET_EXPLORER_9)
#define _INTERNET_EXPLORER_9
#endif

#if defined (_INTERNET_EXPLORER_8)
#define _INTERNET_EXPLORER_8
#endif

#if defined (_INTERNET_EXPLORER_7)
#define _INTERNET_EXPLORER_7
#endif

#if defined (_INTERNET_EXPLORER_6_03)
#define _INTERNET_EXPLORER_6_03
#endif

#if defined (_INTERNET_EXPLORER_6_01)
#define _INTERNET_EXPLORER_6_01
#endif

#if defined (_INTERNET_EXPLORER_6)
#define _INTERNET_EXPLORER_6
#endif

#if defined (_INTERNET_EXPLORER_5_50)
#define _INTERNET_EXPLORER_5_50
#endif

#if defined (_INTERNET_EXPLORER_5_01)
#define _INTERNET_EXPLORER_5_01
#endif

#if defined (_INTERNET_EXPLORER_5)
#define _INTERNET_EXPLORER_5
#endif









#if defined (_WIN32_IE_IE100)
#define _INTERNET_EXPLORER_10
#endif

#if defined (_WIN32_IE_IE900)
#define _INTERNET_EXPLORER_9
#endif

#if defined (_WIN32_IE_IE800)
#define _INTERNET_EXPLORER_8
#endif

#if defined (_WIN32_IE_IE700)
#define _INTERNET_EXPLORER_7
#endif

#if defined (_WIN32_IE_IE603)
#define _INTERNET_EXPLORER_6_03
#endif

#if defined (_WIN32_IE_IE601)
#define _INTERNET_EXPLORER_6_01
#endif

#if defined (_WIN32_IE_IE600)
#define _INTERNET_EXPLORER_6
#endif

#if defined (_WIN32_IE_IE550)
#define _INTERNET_EXPLORER_5_50
#endif

#if defined (_WIN32_IE_IE501)
#define _INTERNET_EXPLORER_5_01
#endif

#if defined (_WIN32_IE_IE500)
#define _INTERNET_EXPLORER_5
#endif









#define _WINDOWS_10




// ��� ������� serial communication API
#define NOCOMM




// OpenMP
#if defined (_OPENMP)
#pragma comment (compiler, "/openmp")
#pragma comment (compiler, "/Zc:twoPhase-")

#include <omp.h>
#endif


#if defined (_M_X64)

	// Win64

#define _WINDOWS_64
#define _WIN_X64
#define _X64
#define _X86_64


#else

	// Win32

#define _WINDOWS_32
#define _WIN_X86
#define _X86

#endif




// ������ Windows
//
// _WIN32_WINNT version constants
//
// #define _WIN32_WINNT_NT4                    0x0400 // Windows NT 4.0
// #define _WIN32_WINNT_WIN2K                  0x0500 // Windows 2000
// #define _WIN32_WINNT_WINXP                  0x0501 // Windows XP
// #define _WIN32_WINNT_WS03                   0x0502 // Windows Server 2003
// #define _WIN32_WINNT_WIN6                   0x0600 // Windows Vista
// #define _WIN32_WINNT_VISTA                  0x0600 // Windows Vista
// #define _WIN32_WINNT_WS08                   0x0600 // Windows Server 2008
// #define _WIN32_WINNT_LONGHORN               0x0600 // Windows Vista
// #define _WIN32_WINNT_WIN7                   0x0601 // Windows 7
// #define _WIN32_WINNT_WIN8                   0x0602 // Windows 8
// #define _WIN32_WINNT_WINBLUE                0x0603 // Windows 8.1
// #define _WIN32_WINNT_WINTHRESHOLD           0x0A00 // Windows 10
// #define _WIN32_WINNT_WIN10                  0x0A00 // Windows 10






#if (_WIN32_WINNT == _WIN32_WINNT_NT4)
#define _WINDOWS_NT4
#endif

#if (_WIN32_WINNT == _WIN32_WINNT_WIN2K)
#define _WINDOWS_2000
#endif



#if (_WIN32_WINNT == _WIN32_WINNT_WINXP)
#define _WINDOWS_XP
#endif

#if (_WIN32_WINNT == _WIN32_WINNT_WS03)
#define _WINDOWS_SERVER_2003
#endif




#if (_WIN32_WINNT == _WIN32_WINNT_WIN6)
#define _WINDOWS_VISTA
#endif

#if (_WIN32_WINNT == _WIN32_WINNT_VISTA)
#define _WINDOWS_VISTA
#endif





#if (_WIN32_WINNT == _WIN32_WINNT_WS08)
#define _WINDOWS_SERVER_2008
#endif

#if (_WIN32_WINNT == _WIN32_WINNT_LONGHORN)
#define _WINDOWS_VISTA
#endif







#if (_WIN32_WINNT == _WIN32_WINNT_WIN7)
#define _WINDOWS_7
#endif

#if (_WIN32_WINNT == _WIN32_WINNT_WIN8)
#define _WINDOWS_8
#endif




#if (_WIN32_WINNT == _WIN32_WINNT_WINBLUE)
#define _WINDOWS_8_1
#endif

#if (_WIN32_WINNT == _WIN32_WINNT_WINTHRESHOLD)
#define _WINDOWS_10
#endif


#if (_WIN32_WINNT == _WIN32_WINNT_WIN10)
#define _WINDOWS_10
#endif



















#if defined (_WINDOWS_NT4)
#define _WIN32_WINNT _WIN32_WINNT_NT4


#endif

#if defined (_WINDOWS_2000)
#define _WIN32_WINNT _WIN32_WINNT_WIN2K
#endif



#if defined (_WINDOWS_XP)
#define _WIN32_WINNT _WIN32_WINNT_WINXP
#endif


#if defined (_WINDOWS_SERVER_2003)
#define _WIN32_WINNT _WIN32_WINNT_WS03
#endif



#if defined (_WINDOWS_VISTA)
#define _WIN32_WINNT _WIN32_WINNT_WIN6

// #define _WIN32_WINNT _WIN32_WINNT_VISTA
// #define _WIN32_WINNT _WIN32_WINNT_LONGHORN

#endif


#if defined (_WINDOWS_SERVER_2008)
#define _WIN32_WINNT _WIN32_WINNT_WS08
#endif









#if defined (_WINDOWS_7)
#define _WIN32_WINNT _WIN32_WINNT_WIN7
#endif


#if defined (_WINDOWS_8)
#define _WIN32_WINNT _WIN32_WINNT_WIN8
#endif


#if defined (_WINDOWS_8_1)
#define _WIN32_WINNT _WIN32_WINNT_WINBLUE
#endif


#if defined (_WINDOWS_10)
#define _WIN32_WINNT _WIN32_WINNT_WIN10
#endif








#define WINVER _WIN32_WINNT




#include <Windows.Definitions.h>

#endif //  STDAFX_H_8F64AC40_65D2_4FAC_8E9F_ECA06EE41FF8







