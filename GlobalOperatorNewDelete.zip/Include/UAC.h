#pragma once

#if !defined UAC_H_E3F8C253_A3B5_4420_988C_F866AFDCF306
#define UAC_H_E3F8C253_A3B5_4420_988C_F866AFDCF306


#include <StdAfx.h>


#pragma comment (lib, "Advapi32.lib")




// �������� ����������
BOOL_MAXIMUM EnablePrivilege (IN HANDLE			hToken,				// access token handle
							  IN CONST WCHAR 	*pwcPrivilege)		// name of privilege to enable/disable
{

	TOKEN_PRIVILEGES sTokenPrivileges;

	LUID sLUID;


	if (::LookupPrivilegeValue (NULL,            // lookup privilege on local system
								pwcPrivilege,   // privilege to lookup
								&sLUID ) )        // receives LUID of privilege
	{

		sTokenPrivileges.PrivilegeCount				= 1;
		sTokenPrivileges.Privileges[0].Luid			= sLUID;
		sTokenPrivileges.Privileges[0].Attributes	= SE_PRIVILEGE_ENABLED;

		// Enable the privilege or disable all privileges.

		if (::AdjustTokenPrivileges (hToken,
									 FALSE,
									 &sTokenPrivileges,
									 sizeof (TOKEN_PRIVILEGES),
									 (PTOKEN_PRIVILEGES) NULL,
									 (DWORD *) NULL))
		{
			if (::GetLastError () != ERROR_NOT_ALL_ASSIGNED)
			{
				return (TRUE);
			}

		}


	}



	return (FALSE);
}







// ��������� ����������
BOOL_MAXIMUM DisablePrivilege (IN HANDLE		hToken,				// access token handle
							   IN CONST WCHAR	*pwcPrivilege)		// name of privilege to enable/disable
{

	TOKEN_PRIVILEGES sTokenPrivileges;

	LUID sLUID;


	if (LookupPrivilegeValue (
		NULL,            // lookup privilege on local system
		pwcPrivilege,   // privilege to lookup
		&sLUID))        // receives LUID of privilege
	{

		sTokenPrivileges.PrivilegeCount = 1;
		sTokenPrivileges.Privileges[0].Luid = sLUID;
		sTokenPrivileges.Privileges[0].Attributes = NULL;

		// Enable the privilege or disable all privileges.

		if (AdjustTokenPrivileges (hToken,
								   FALSE,
								   &sTokenPrivileges,
								   sizeof (TOKEN_PRIVILEGES),
								   (PTOKEN_PRIVILEGES) NULL,
								   (PDWORD) NULL))
		{
			if (GetLastError () != ERROR_NOT_ALL_ASSIGNED)
			{
				return (TRUE);
			}

		}


	}



	return (FALSE);
}



















#endif
