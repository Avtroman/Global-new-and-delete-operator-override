#pragma once

#ifndef WINDOWS_DEFINITIONS_H_DB2B2E79_8998_481D_81A2_649750AF70DB
#define WINDOWS_DEFINITIONS_H_DB2B2E79_8998_481D_81A2_649750AF70DB












#ifndef NULL
	#ifdef __cplusplus
		#define NULL 0
	#else
		#define NULL ((void *)0)
	#endif
#endif







#define IN

#define OUT



typedef				unsigned char					BYTE; //-V677

typedef				char							CHAR; //-V677


typedef				double							DOUBLE;


#if defined (_M_X64)

typedef				unsigned __int64				BOOL_MAXIMUM;

//typedef				unsigned __int64				BOOLEAN;


typedef				long long						LONG64;

typedef				unsigned long long				ULONG64;




typedef				wchar_t							WCHAR;


typedef				long long						LONG_MAXIMUM;

typedef				unsigned long long				ULONG_MAXIMUM;




typedef				long long						INT_MAXIMUM;
typedef				unsigned long long				UINT_MAXIMUM;


typedef				long							LONG;

typedef				unsigned long					ULONG;





#else



typedef				unsigned long					BOOL_MAXIMUM;


//typedef				unsigned long					BOOLEAN;


typedef				long							LONG_MAXIMUM;
typedef				unsigned long					ULONG_MAXIMUM;



typedef				int								INT_MAXIMUM;
typedef				unsigned int					UINT_MAXIMUM;


typedef				long							LONG; //-V677

typedef				unsigned long					ULONG; //-V677






#endif












// #undef _ALIGN
// #undef _ALIGN4
// #undef _ALIGN8
// #undef _ALIGN16
// #undef _ALIGN32
// #undef _ALIGN64
// #undef _ALIGN128

#if defined (_M_X64)

	#define _ALIGNED					__declspec(align(16))


#else

	#define _ALIGNED					__declspec(align(4))

#endif





#define _ALIGN4					__declspec(align(4))
#define _ALIGN8					__declspec(align(8))
#define _ALIGN16				__declspec(align(16))
#define _ALIGN32				__declspec(align(32))
#define _ALIGN64				__declspec(align(64))
#define _ALIGN128				__declspec(align(128))



#define _ALIGN(x) __declspec(align(x))



#define VOID					void


#define _GETALIGN(x)			__alignof(x)



#define _DLLEXPORT				__declspec(dllexport)
#define _DLLIMPORT				__declspec(dllimport)



//#undef _FORCEINLINE
#define _FORCEINLINE __forceinline










#if defined (_DDRAW)
	#include <Ddraw.h>
#endif


#endif //  WINDOWS_DEFINITIONS_H_DB2B2E79_8998_481D_81A2_649750AF70DB




